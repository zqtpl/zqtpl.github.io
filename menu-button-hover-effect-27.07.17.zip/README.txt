A Pen created at CodePen.io. You can find this one at http://codepen.io/pcameron/pen/qEBrew.

 Day 14 - CSS Menu Button with hover effect. Not much time today at all sorry! 
@cameroncodes